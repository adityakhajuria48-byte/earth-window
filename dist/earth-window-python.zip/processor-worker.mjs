// Sites checks the owner-private audience before dispatching requests here.
export async function handleRequest(request, env, assets = {}) {
  const url = new URL(request.url), path = url.pathname;
  const configured = Boolean(env.EARTH_WINDOW_PROCESSOR_URL && env.EARTH_WINDOW_PROCESSOR_PASSWORD);
  const json = (status, error) => Response.json({error}, {status, headers:{'Cache-Control':'no-store'}});
  if (path.startsWith('/api/')) {
    if (!request.headers.get('oai-authenticated-user-id')) return json(401, 'Sign in to Earth Window to process a crop.');
    if (!['/api/crop', '/api/preview', '/api/aoi', '/api/health'].includes(path)) return json(404, 'Unknown endpoint.');
    if (request.method !== (path === '/api/health' ? 'GET' : 'POST')) return json(405, 'Method not allowed.');
    if (!configured) return json(503, 'Crop processing is not connected yet.');
    const origin = request.headers.get('Origin');
    if ((origin && origin !== url.origin) || request.headers.get('Sec-Fetch-Site') === 'cross-site') return json(403, 'Start the export from Earth Window.');
    const upload = path === '/api/aoi', maxBody = upload ? 10 * 1024 * 1024 : 8192;
    const requestType = upload ? 'application/zip' : 'application/json';
    let body;
    if (path !== '/api/health') {
      if (!(request.headers.get('Content-Type') || '').startsWith(requestType)) return json(400, upload ? 'Upload a zipped shapefile.' : 'Expected a JSON crop request.');
      const declared = Number(request.headers.get('Content-Length'));
      if (declared > maxBody) return json(413, upload ? 'Upload a ZIP smaller than 10 MB.' : 'Crop request is too large.');
      // Do not buffer an unbounded request when Content-Length is absent or incorrect.
      const reader = request.body?.getReader();
      if (!reader) return json(400, 'Missing crop request.');
      let size = 0; const chunks = [];
      try {
        while (true) {
          const {done, value} = await reader.read(); if (done) break;
          size += value.byteLength;
          if (size > maxBody) { await reader.cancel(); return json(413, upload ? 'Upload a ZIP smaller than 10 MB.' : 'Crop request is too large.'); }
          chunks.push(value);
        }
      } finally { reader.releaseLock(); }
      body = new Uint8Array(size); let offset = 0;
      for (const chunk of chunks) { body.set(chunk, offset); offset += chunk.byteLength; }
    }
    try {
      const upstream = new URL(env.EARTH_WINDOW_PROCESSOR_URL);
      if (upstream.protocol !== 'https:' || upstream.username || upstream.password) return json(503, 'Invalid processing service configuration.');
      upstream.pathname = path; upstream.search = '';
      const response = await fetch(upstream, {
        method: request.method, body, redirect:'error', signal:AbortSignal.timeout(145000),
        headers:{'Content-Type':requestType, Authorization:'Basic '+btoa('earth-window:'+env.EARTH_WINDOW_PROCESSOR_PASSWORD)},
      });
      const contentType = response.headers.get('Content-Type') || '';
      if (!contentType.includes('application/json') && !contentType.includes('image/tiff')) return json(502, 'The crop service is waking up or unavailable. Please retry shortly.');
      const headers = new Headers({'Content-Type':contentType, 'Cache-Control':'no-store', 'X-Content-Type-Options':'nosniff'});
      if (response.ok && contentType.includes('image/tiff')) headers.set('Content-Disposition', 'attachment; filename="earth-window-crop.tif"');
      return new Response(response.body, {status:response.status, headers});
    } catch (error) {
      return error.name === 'TimeoutError' || error.name === 'AbortError'
        ? json(504, 'The processing service did not respond in time. Retry or select a smaller area.')
        : json(502, 'Cannot reach the processing service. Please retry shortly; you can also open the original band file.');
    }
  }
  if (!['GET','HEAD'].includes(request.method)) return json(405, 'Method not allowed.');
  if (path === '/backend-config.js') {
    return new Response(request.method === 'HEAD' ? null : `window.EARTH_WINDOW_PYTHON = false; window.EARTH_WINDOW_CROPS = ${configured};`, {headers:{'Content-Type':'text/javascript; charset=utf-8','Cache-Control':'no-store'}});
  }
  const asset = assets[path === '/' ? '/index.html' : path];
  if (!asset) return new Response('Not found', {status:404});
  const body = request.method === 'HEAD' ? null : asset.binary ? Uint8Array.from(atob(asset.data), c=>c.charCodeAt(0)) : asset.data;
  return new Response(body, {headers:{'Content-Type':asset.type, 'Cache-Control':'no-cache','X-Content-Type-Options':'nosniff','Referrer-Policy':'strict-origin-when-cross-origin'}});
}
